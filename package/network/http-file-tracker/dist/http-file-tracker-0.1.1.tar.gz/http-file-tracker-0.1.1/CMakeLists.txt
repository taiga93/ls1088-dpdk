cmake_minimum_required(VERSION 3.16)
project(http_file_tracker VERSION 0.1.1 LANGUAGES CXX)

option(HTTP_FILE_TRACKER_BUILD_TESTS "Build unit tests" ON)
option(HTTP_FILE_TRACKER_ENABLE_PCAP "Build PcapPlusPlus capture integration" ON)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

find_package(Threads REQUIRED)

add_library(hft_core
  src/app/Version.cpp
  src/core/IpAddress.cpp
  src/config/RuntimeConfig.cpp
  src/config/ArgsParser.cpp
  src/http/HttpParser.cpp
  src/http/MultipartParser.cpp
  src/log/KvLog.cpp
  src/log/SyslogLogger.cpp
  src/detect/TransferDetector.cpp
  src/flow/FlowTracker.cpp
)
target_include_directories(hft_core PUBLIC src)
target_compile_options(hft_core PRIVATE -Wall -Wextra -Wpedantic)
target_link_libraries(hft_core PUBLIC Threads::Threads)

if(HTTP_FILE_TRACKER_ENABLE_PCAP)
  find_package(PcapPlusPlus QUIET)
  target_sources(hft_core PRIVATE src/capture/PcapCapture.cpp)
  if(PcapPlusPlus_FOUND)
    target_link_libraries(hft_core PUBLIC PcapPlusPlus::Pcap++ PcapPlusPlus::Packet++ PcapPlusPlus::Common++)
  else()
    find_path(PCAPPLUSPLUS_INCLUDE_DIR
      NAMES PcapLiveDevice.h
      PATH_SUFFIXES pcapplusplus)
    find_library(PCAPPLUSPLUS_PCAPPP_LIBRARY NAMES Pcap++)
    find_library(PCAPPLUSPLUS_PACKETPP_LIBRARY NAMES Packet++)
    find_library(PCAPPLUSPLUS_COMMONPP_LIBRARY NAMES Common++)
    find_library(PCAP_LIBRARY NAMES pcap)

    if(NOT PCAPPLUSPLUS_INCLUDE_DIR OR
       NOT PCAPPLUSPLUS_PCAPPP_LIBRARY OR
       NOT PCAPPLUSPLUS_PACKETPP_LIBRARY OR
       NOT PCAPPLUSPLUS_COMMONPP_LIBRARY OR
       NOT PCAP_LIBRARY)
      message(FATAL_ERROR
        "PcapPlusPlus was not found. Install/provide PcapPlusPlus headers and "
        "libraries, or set HTTP_FILE_TRACKER_ENABLE_PCAP=OFF for host-only tests.")
    endif()

    target_include_directories(hft_core PUBLIC ${PCAPPLUSPLUS_INCLUDE_DIR})
    target_link_libraries(hft_core PUBLIC
      ${PCAPPLUSPLUS_PCAPPP_LIBRARY}
      ${PCAPPLUSPLUS_PACKETPP_LIBRARY}
      ${PCAPPLUSPLUS_COMMONPP_LIBRARY}
      ${PCAP_LIBRARY})
  endif()
else()
  target_sources(hft_core PRIVATE src/capture/PcapCaptureStub.cpp)
endif()

add_executable(http-file-tracker src/main.cpp)
target_link_libraries(http-file-tracker PRIVATE hft_core)
install(TARGETS http-file-tracker RUNTIME DESTINATION sbin)

if(HTTP_FILE_TRACKER_BUILD_TESTS)
  enable_testing()
  add_test(NAME hft_disabled_cli_test
    COMMAND http-file-tracker --interface br-lan --lan-client 192.168.1.10 --disabled)

  add_executable(hft_version_test tests/unit/VersionTest.cpp)
  target_include_directories(hft_version_test PRIVATE src tests/unit)
  target_link_libraries(hft_version_test PRIVATE hft_core)
  add_test(NAME hft_version_test COMMAND hft_version_test)

  add_executable(hft_ip_address_test tests/unit/IpAddressTest.cpp)
  target_include_directories(hft_ip_address_test PRIVATE src tests/unit)
  target_link_libraries(hft_ip_address_test PRIVATE hft_core)
  add_test(NAME hft_ip_address_test COMMAND hft_ip_address_test)

  add_executable(hft_config_test tests/unit/ConfigTest.cpp)
  target_include_directories(hft_config_test PRIVATE src tests/unit)
  target_link_libraries(hft_config_test PRIVATE hft_core)
  add_test(NAME hft_config_test COMMAND hft_config_test)

  add_executable(hft_kv_log_test tests/unit/KvLogTest.cpp)
  target_include_directories(hft_kv_log_test PRIVATE src tests/unit)
  target_link_libraries(hft_kv_log_test PRIVATE hft_core)
  add_test(NAME hft_kv_log_test COMMAND hft_kv_log_test)

  add_executable(hft_http_parser_header_test tests/unit/HttpParserHeaderTest.cpp)
  target_include_directories(hft_http_parser_header_test PRIVATE src tests/unit)
  target_link_libraries(hft_http_parser_header_test PRIVATE hft_core)
  add_test(NAME hft_http_parser_header_test COMMAND hft_http_parser_header_test)

  add_executable(hft_http_body_test tests/unit/HttpBodyTest.cpp)
  target_include_directories(hft_http_body_test PRIVATE src tests/unit)
  target_link_libraries(hft_http_body_test PRIVATE hft_core)
  add_test(NAME hft_http_body_test COMMAND hft_http_body_test)

  add_executable(hft_multipart_parser_test tests/unit/MultipartParserTest.cpp)
  target_include_directories(hft_multipart_parser_test PRIVATE src tests/unit)
  target_link_libraries(hft_multipart_parser_test PRIVATE hft_core)
  add_test(NAME hft_multipart_parser_test COMMAND hft_multipart_parser_test)

  add_executable(hft_transfer_detector_test tests/unit/TransferDetectorTest.cpp)
  target_include_directories(hft_transfer_detector_test PRIVATE src tests/unit)
  target_link_libraries(hft_transfer_detector_test PRIVATE hft_core)
  add_test(NAME hft_transfer_detector_test COMMAND hft_transfer_detector_test)

  add_executable(hft_flow_tracker_test tests/unit/FlowTrackerTest.cpp)
  target_include_directories(hft_flow_tracker_test PRIVATE src tests/unit)
  target_link_libraries(hft_flow_tracker_test PRIVATE hft_core)
  add_test(NAME hft_flow_tracker_test COMMAND hft_flow_tracker_test)

  add_test(NAME hft_init_script_test
    COMMAND sh ${CMAKE_CURRENT_SOURCE_DIR}/tests/unit/InitScriptTest.sh)

  add_test(NAME hft_openwrt_package_test
    COMMAND sh ${CMAKE_CURRENT_SOURCE_DIR}/tests/unit/OpenWrtPackageTest.sh)
endif()

if(HTTP_FILE_TRACKER_BUILD_TESTS AND HTTP_FILE_TRACKER_ENABLE_PCAP)
  add_executable(hft_pcap_replay_test tests/pcap/PcapReplayTest.cpp)
  target_include_directories(hft_pcap_replay_test PRIVATE src tests/unit)
  target_link_libraries(hft_pcap_replay_test PRIVATE hft_core)
  add_test(NAME hft_pcap_replay_test COMMAND hft_pcap_replay_test)
endif()
