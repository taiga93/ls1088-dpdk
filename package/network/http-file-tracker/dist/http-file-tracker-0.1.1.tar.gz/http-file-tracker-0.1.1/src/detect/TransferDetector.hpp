#pragma once

#include "config/RuntimeConfig.hpp"
#include "core/IpAddress.hpp"
#include "http/MultipartParser.hpp"
#include "http/HttpTypes.hpp"

#include <cstdint>
#include <deque>
#include <optional>
#include <string>
#include <vector>

namespace hft {

struct Endpoint {
  std::string ip;
  uint16_t port = 0;
};

class TransferDetector {
 public:
  TransferDetector(RuntimeConfig config, std::string start_ts);

  void onHttpMessage(const Endpoint& src,
                     const Endpoint& dst,
                     const HttpMessage& message,
                     bool from_client);
  std::vector<TransferEvent> onBodyProgress(bool from_client,
                                            const BodyProgress& progress,
                                            const std::string& now_ts);
  std::vector<TransferEvent> onMultipartBytes(std::string_view bytes,
                                              const std::string& now_ts);
  std::vector<TransferEvent> flushDirection(bool from_client,
                                            const std::string& reason,
                                            const std::string& now_ts);
  std::vector<TransferEvent> flushTimeout(const std::string& reason,
                                         const std::string& now_ts);

 private:
  struct RequestContext {
    Endpoint client;
    Endpoint peer;
    std::string method;
    std::string uri;
    std::string host;
  };

  struct ActiveTransfer {
    TransferEvent event;
    uint64_t threshold = 0;
    bool emitted = false;
  };

  struct MultipartUpload {
    ActiveTransfer base;
    MultipartParser parser;
    std::optional<TransferEvent> active_file;

    MultipartUpload(ActiveTransfer transfer,
                    std::string boundary,
                    uint32_t max_header_bytes,
                    uint32_t max_filename_bytes)
        : base(std::move(transfer)),
          parser(std::move(boundary), max_header_bytes, max_filename_bytes) {}
  };

  RuntimeConfig config_;
  IpMatcher lan_matcher_;
  std::string start_ts_;
  std::deque<RequestContext> pending_requests_;
  std::optional<ActiveTransfer> upload_;
  std::optional<ActiveTransfer> download_;
  std::optional<MultipartUpload> multipart_upload_;

  ActiveTransfer makeTransfer(const RequestContext& request,
                              const Endpoint& peer,
                              const HttpMessage& message,
                              bool upload);
  std::vector<TransferEvent> processMultipartEvents(
      const std::vector<MultipartEvent>& multipart_events,
      const std::string& now_ts);
};

std::string filenameFromUri(const std::string& uri);
std::optional<uint64_t> declaredSizeFromContentRange(const std::string& value);

}  // namespace hft
