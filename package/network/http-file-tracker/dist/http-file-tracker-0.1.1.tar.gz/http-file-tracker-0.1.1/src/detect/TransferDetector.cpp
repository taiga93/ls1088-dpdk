#include "detect/TransferDetector.hpp"

#include "core/Clock.hpp"

#include <string_view>
#include <utility>

namespace hft {
namespace {

bool hasFilenameExtension(const std::string& name) {
  const auto dot = name.find_last_of('.');
  return dot != std::string::npos && dot + 1 < name.size() &&
         name.size() - dot <= 8;
}

std::string unquote(std::string value) {
  if (value.size() >= 2 && value.front() == '"' && value.back() == '"') {
    value = value.substr(1, value.size() - 2);
  }
  return value;
}

std::string filenameParamFromContentDisposition(const std::string& value) {
  size_t pos = 0;
  while ((pos = value.find(';', pos)) != std::string::npos) {
    ++pos;
    while (pos < value.size() && (value[pos] == ' ' || value[pos] == '\t')) {
      ++pos;
    }

    const size_t key_start = pos;
    const size_t equals = value.find('=', key_start);
    if (equals == std::string::npos) {
      break;
    }
    const std::string key = value.substr(key_start, equals - key_start);
    const size_t value_end = value.find(';', equals + 1);
    std::string param = value.substr(equals + 1, value_end - (equals + 1));
    if (key == "filename") {
      return unquote(std::move(param));
    }
    pos = value_end == std::string::npos ? value.size() : value_end;
  }
  return "";
}

std::string explicitFilenameFromHeaders(const HttpMessage& message,
                                        uint32_t max_filename_bytes) {
  std::string filename;

  const auto x_filename = message.headers.find("x-filename");
  if (x_filename != message.headers.end()) {
    filename = x_filename->second;
  }

  if (filename.empty() && !message.content_disposition.empty()) {
    filename =
        filenameParamFromContentDisposition(message.content_disposition);
  }

  if (filename.size() > max_filename_bytes) {
    filename.resize(max_filename_bytes);
  }
  return filename;
}

uint64_t durationMs(const std::string& start_ts, const std::string& end_ts) {
  const auto seconds = elapsedSeconds(start_ts, end_ts);
  return seconds ? *seconds * 1000 : 0;
}

}  // namespace

std::string filenameFromUri(const std::string& uri) {
  const auto query = uri.find('?');
  const std::string path = uri.substr(0, query);
  const auto slash = path.find_last_of('/');
  const std::string name =
      slash == std::string::npos ? path : path.substr(slash + 1);
  return hasFilenameExtension(name) ? name : "";
}

std::optional<uint64_t> declaredSizeFromContentRange(const std::string& value) {
  const auto slash = value.find('/');
  if (slash == std::string::npos) {
    return std::nullopt;
  }

  const std::string total = value.substr(slash + 1);
  if (total == "*") {
    return std::nullopt;
  }

  uint64_t result = 0;
  for (char ch : total) {
    if (ch < '0' || ch > '9') {
      return std::nullopt;
    }
    result = result * 10 + static_cast<uint64_t>(ch - '0');
  }
  return result;
}

TransferDetector::TransferDetector(RuntimeConfig config, std::string start_ts)
    : config_(std::move(config)), start_ts_(std::move(start_ts)) {
  for (const auto& pattern : config_.lan_clients) {
    std::string error;
    lan_matcher_.addPattern(pattern, &error);
  }
}

void TransferDetector::onHttpMessage(const Endpoint& src,
                                     const Endpoint& dst,
                                     const HttpMessage& message,
                                     bool from_client) {
  if (message.is_request) {
    RequestContext request;
    request.client = src;
    request.peer = dst;
    request.method = message.method;
    request.uri = message.uri;
    const auto host = message.headers.find("host");
    request.host = host == message.headers.end() ? dst.ip : host->second;
    pending_requests_.push_back(request);

    if (message.body_mode != BodyMode::NoBody) {
      const std::string boundary =
          multipartBoundaryFromContentType(message.content_type);
      if (!boundary.empty()) {
        multipart_upload_.emplace(makeTransfer(request, dst, message, true),
                                  boundary,
                                  config_.max_header_bytes,
                                  config_.max_filename_bytes);
        upload_.reset();
      } else {
        upload_ = makeTransfer(request, dst, message, true);
        multipart_upload_.reset();
      }
    }
    return;
  }

  if (!from_client && !pending_requests_.empty()) {
    const RequestContext request = pending_requests_.front();
    pending_requests_.pop_front();
    if (message.body_mode != BodyMode::NoBody) {
      download_ = makeTransfer(request, src, message, false);
    }
  }
}

TransferDetector::ActiveTransfer TransferDetector::makeTransfer(
    const RequestContext& request,
    const Endpoint& peer,
    const HttpMessage& message,
    bool upload) {
  ActiveTransfer active;
  active.threshold = config_.body_threshold_bytes;

  TransferEvent event;
  event.status = TransferStatus::Complete;
  event.direction = upload ? Direction::Upload : Direction::Download;
  if (lan_matcher_.matches(request.client.ip) && lan_matcher_.matches(peer.ip)) {
    event.direction = upload ? Direction::LanUpload : Direction::LanDownload;
  }
  event.client_ip = request.client.ip;
  event.peer_ip = peer.ip;
  event.host = request.host.empty() ? peer.ip : request.host;
  event.uri = request.uri;
  event.content_type = message.content_type;
  event.start_ts = start_ts_;

  const std::string explicit_filename =
      explicitFilenameFromHeaders(message, config_.max_filename_bytes);
  if (!explicit_filename.empty()) {
    event.kind = TransferKind::FileDetected;
    event.filename = explicit_filename;
    event.confidence = "high";
  } else if (const std::string uri_filename = filenameFromUri(request.uri);
             !uri_filename.empty()) {
    event.kind = TransferKind::FileDetected;
    event.filename = uri_filename;
    event.confidence = "medium";
  } else {
    event.kind = TransferKind::BodyTransfer;
    event.filename = "unknown";
    event.confidence = "low";
  }

  event.declared_size = message.declared_body_size;
  const auto range = message.headers.find("content-range");
  if (range != message.headers.end()) {
    event.declared_size = declaredSizeFromContentRange(range->second);
  }

  active.event = std::move(event);
  return active;
}

std::vector<TransferEvent> TransferDetector::onBodyProgress(
    bool from_client,
    const BodyProgress& progress,
    const std::string& now_ts) {
  std::vector<TransferEvent> events;
  if (from_client && multipart_upload_) {
    (void)progress;
    (void)now_ts;
    return events;
  }
  auto& active = from_client ? upload_ : download_;
  if (!active) {
    return events;
  }

  active->event.bytes_transferred += progress.bytes;
  const bool threshold_met =
      active->event.kind == TransferKind::FileDetected ||
      config_.track_small_bodies ||
      active->event.bytes_transferred >= active->threshold;

  if (progress.complete && threshold_met) {
    active->event.end_ts = now_ts;
    active->event.duration_ms = durationMs(active->event.start_ts, now_ts);
    events.push_back(active->event);
    active.reset();
  } else if (progress.complete) {
    active.reset();
  }

  return events;
}

std::vector<TransferEvent> TransferDetector::processMultipartEvents(
    const std::vector<MultipartEvent>& multipart_events,
    const std::string& now_ts) {
  std::vector<TransferEvent> events;
  if (!multipart_upload_) {
    return events;
  }

  for (const MultipartEvent& multipart_event : multipart_events) {
    if (multipart_event.type == MultipartEventType::FileStart) {
      TransferEvent event = multipart_upload_->base.event;
      event.kind = TransferKind::FileDetected;
      event.status = TransferStatus::Complete;
      event.filename = multipart_event.filename.empty() ? "unknown"
                                                        : multipart_event.filename;
      event.content_type = multipart_event.content_type;
      event.bytes_transferred = 0;
      event.confidence = "high";
      event.reason.clear();
      event.end_ts.clear();
      event.duration_ms = 0;
      multipart_upload_->active_file = std::move(event);
      continue;
    }

    if (multipart_event.type == MultipartEventType::FileEnd) {
      if (!multipart_upload_->active_file) {
        continue;
      }
      multipart_upload_->active_file->bytes_transferred = multipart_event.bytes;
      multipart_upload_->active_file->end_ts = now_ts;
      multipart_upload_->active_file->duration_ms =
          durationMs(multipart_upload_->active_file->start_ts, now_ts);
      events.push_back(*multipart_upload_->active_file);
      multipart_upload_->active_file.reset();
      continue;
    }

    if (multipart_event.type == MultipartEventType::ParserError &&
        multipart_upload_->active_file) {
      multipart_upload_->active_file->status = TransferStatus::Partial;
      multipart_upload_->active_file->reason = multipart_event.reason;
      multipart_upload_->active_file->bytes_transferred = multipart_event.bytes;
      multipart_upload_->active_file->end_ts = now_ts;
      multipart_upload_->active_file->duration_ms =
          durationMs(multipart_upload_->active_file->start_ts, now_ts);
      events.push_back(*multipart_upload_->active_file);
      multipart_upload_->active_file.reset();
    }
  }

  return events;
}

std::vector<TransferEvent> TransferDetector::onMultipartBytes(
    std::string_view bytes,
    const std::string& now_ts) {
  if (!multipart_upload_) {
    return {};
  }

  return processMultipartEvents(multipart_upload_->parser.feed(bytes), now_ts);
}

std::vector<TransferEvent> TransferDetector::flushDirection(
    bool from_client,
    const std::string& reason,
    const std::string& now_ts) {
  std::vector<TransferEvent> events;
  auto flush = [&](std::optional<ActiveTransfer>& active) {
    if (!active) {
      return;
    }
    active->event.status = TransferStatus::Timeout;
    active->event.reason = reason;
    active->event.end_ts = now_ts;
    active->event.duration_ms = durationMs(active->event.start_ts, now_ts);
    if (active->event.kind == TransferKind::FileDetected ||
        config_.track_small_bodies ||
        active->event.bytes_transferred >= active->threshold) {
      events.push_back(active->event);
    }
    active.reset();
  };

  if (from_client) {
    flush(upload_);
    if (multipart_upload_) {
      auto partial_events = processMultipartEvents(
          multipart_upload_->parser.finishPartial(reason), now_ts);
      events.insert(events.end(), partial_events.begin(), partial_events.end());
      multipart_upload_.reset();
    }
  } else {
    flush(download_);
  }

  return events;
}

std::vector<TransferEvent> TransferDetector::flushTimeout(
    const std::string& reason,
    const std::string& now_ts) {
  std::vector<TransferEvent> events;
  auto flush = [&](std::optional<ActiveTransfer>& active) {
    if (!active) {
      return;
    }
    active->event.status = TransferStatus::Timeout;
    active->event.reason = reason;
    active->event.end_ts = now_ts;
    active->event.duration_ms = durationMs(active->event.start_ts, now_ts);
    if (active->event.kind == TransferKind::FileDetected ||
        config_.track_small_bodies ||
        active->event.bytes_transferred >= active->threshold) {
      events.push_back(active->event);
    }
    active.reset();
  };

  flush(upload_);
  flush(download_);
  if (multipart_upload_) {
    auto partial_events = processMultipartEvents(
        multipart_upload_->parser.finishPartial(reason), now_ts);
    events.insert(events.end(), partial_events.begin(), partial_events.end());
    multipart_upload_.reset();
  }
  return events;
}

}  // namespace hft
