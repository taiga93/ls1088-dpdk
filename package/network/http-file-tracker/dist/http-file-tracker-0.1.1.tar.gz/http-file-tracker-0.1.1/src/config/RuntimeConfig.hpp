#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace hft {

struct RuntimeConfig {
  bool enabled = true;
  std::vector<std::string> interfaces;
  std::vector<uint16_t> http_ports{80, 8080, 8000, 8888};
  std::vector<std::string> lan_clients;
  uint64_t body_threshold_bytes = 65536;
  bool track_small_bodies = false;
  uint32_t max_active_flows = 4096;
  uint32_t max_header_bytes = 32768;
  uint32_t max_uri_bytes = 2048;
  uint32_t max_filename_bytes = 512;
  uint32_t flow_idle_timeout_sec = 120;
  uint32_t capture_snaplen = 262144;
};

struct ConfigResult {
  bool ok = false;
  RuntimeConfig config;
  std::string error;
};

std::string buildBpfFilter(const RuntimeConfig& config);
bool validateConfig(const RuntimeConfig& config, std::string* error);

}  // namespace hft
