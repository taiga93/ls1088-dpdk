#include "config/RuntimeConfig.hpp"

#include "core/IpAddress.hpp"

#include <sstream>

namespace hft {

bool validateConfig(const RuntimeConfig& config, std::string* error) {
  if (!config.enabled) {
    return true;
  }

  if (config.interfaces.empty()) {
    if (error) {
      *error = "at least one --interface is required";
    }
    return false;
  }

  if (config.lan_clients.empty()) {
    if (error) {
      *error = "at least one --lan-client is required";
    }
    return false;
  }

  for (const auto& client : config.lan_clients) {
    ParsedIp network;
    uint8_t prefix = 0;
    if (!parseIpPattern(client, &network, &prefix, error)) {
      return false;
    }
  }

  if (config.http_ports.empty()) {
    if (error) {
      *error = "at least one --http-port is required";
    }
    return false;
  }

  if (config.max_header_bytes < 1024) {
    if (error) {
      *error = "--max-header-bytes must be at least 1024";
    }
    return false;
  }

  if (config.max_filename_bytes < 64) {
    if (error) {
      *error = "--max-filename-bytes must be at least 64";
    }
    return false;
  }

  if (config.capture_snaplen < 262144) {
    if (error) {
      *error = "--capture-snaplen must be at least 262144";
    }
    return false;
  }

  return true;
}

std::string buildBpfFilter(const RuntimeConfig& config) {
  std::ostringstream out;
  out << "tcp and (";
  for (std::size_t i = 0; i < config.http_ports.size(); ++i) {
    if (i != 0) {
      out << " or ";
    }
    out << "port " << config.http_ports[i];
  }
  out << ")";
  return out.str();
}

}  // namespace hft
