#include "config/ArgsParser.hpp"

#include <cstdlib>
#include <limits>
#include <string>

namespace hft {
namespace {

bool parseUint64(const std::string& value,
                 uint64_t min_value,
                 uint64_t max_value,
                 uint64_t* out) {
  if (value.empty()) {
    return false;
  }

  char* end = nullptr;
  const unsigned long long parsed = std::strtoull(value.c_str(), &end, 10);
  if (*end != '\0') {
    return false;
  }
  if (parsed < min_value || parsed > max_value) {
    return false;
  }

  *out = static_cast<uint64_t>(parsed);
  return true;
}

bool requireValue(int index, int argc, const std::string& flag, ConfigResult* result) {
  if (index + 1 < argc) {
    return true;
  }
  result->ok = false;
  result->error = flag + " requires a value";
  return false;
}

}  // namespace

ConfigResult parseArgs(int argc, const char* const argv[]) {
  ConfigResult result;
  RuntimeConfig config;
  bool saw_custom_port = false;

  for (int i = 1; i < argc; ++i) {
    const std::string arg = argv[i];
    if (arg == "--interface") {
      if (!requireValue(i, argc, arg, &result)) {
        return result;
      }
      config.interfaces.push_back(argv[++i]);
    } else if (arg == "--lan-client") {
      if (!requireValue(i, argc, arg, &result)) {
        return result;
      }
      config.lan_clients.push_back(argv[++i]);
    } else if (arg == "--http-port") {
      if (!requireValue(i, argc, arg, &result)) {
        return result;
      }
      if (!saw_custom_port) {
        config.http_ports.clear();
        saw_custom_port = true;
      }
      uint64_t value = 0;
      if (!parseUint64(argv[++i], 1, 65535, &value)) {
        result.error = "invalid --http-port";
        return result;
      }
      config.http_ports.push_back(static_cast<uint16_t>(value));
    } else if (arg == "--body-threshold-bytes") {
      if (!requireValue(i, argc, arg, &result)) {
        return result;
      }
      uint64_t value = 0;
      if (!parseUint64(argv[++i], 0, std::numeric_limits<uint64_t>::max(), &value)) {
        result.error = "invalid --body-threshold-bytes";
        return result;
      }
      config.body_threshold_bytes = value;
    } else if (arg == "--track-small-bodies") {
      config.track_small_bodies = true;
    } else if (arg == "--max-active-flows") {
      if (!requireValue(i, argc, arg, &result)) {
        return result;
      }
      uint64_t value = 0;
      if (!parseUint64(argv[++i], 1, 1000000, &value)) {
        result.error = "invalid --max-active-flows";
        return result;
      }
      config.max_active_flows = static_cast<uint32_t>(value);
    } else if (arg == "--max-header-bytes") {
      if (!requireValue(i, argc, arg, &result)) {
        return result;
      }
      uint64_t value = 0;
      if (!parseUint64(argv[++i], 1024, 1048576, &value)) {
        result.error = "invalid --max-header-bytes";
        return result;
      }
      config.max_header_bytes = static_cast<uint32_t>(value);
    } else if (arg == "--max-uri-bytes") {
      if (!requireValue(i, argc, arg, &result)) {
        return result;
      }
      uint64_t value = 0;
      if (!parseUint64(argv[++i], 64, 65535, &value)) {
        result.error = "invalid --max-uri-bytes";
        return result;
      }
      config.max_uri_bytes = static_cast<uint32_t>(value);
    } else if (arg == "--max-filename-bytes") {
      if (!requireValue(i, argc, arg, &result)) {
        return result;
      }
      uint64_t value = 0;
      if (!parseUint64(argv[++i], 64, 65535, &value)) {
        result.error = "invalid --max-filename-bytes";
        return result;
      }
      config.max_filename_bytes = static_cast<uint32_t>(value);
    } else if (arg == "--flow-idle-timeout-sec") {
      if (!requireValue(i, argc, arg, &result)) {
        return result;
      }
      uint64_t value = 0;
      if (!parseUint64(argv[++i], 1, 86400, &value)) {
        result.error = "invalid --flow-idle-timeout-sec";
        return result;
      }
      config.flow_idle_timeout_sec = static_cast<uint32_t>(value);
    } else if (arg == "--capture-snaplen") {
      if (!requireValue(i, argc, arg, &result)) {
        return result;
      }
      uint64_t value = 0;
      if (!parseUint64(argv[++i], 262144, 1048576, &value)) {
        result.error = "invalid --capture-snaplen";
        return result;
      }
      config.capture_snaplen = static_cast<uint32_t>(value);
    } else if (arg == "--disabled") {
      config.enabled = false;
    } else {
      result.error = "unknown argument: " + arg;
      return result;
    }
  }

  std::string error;
  if (!validateConfig(config, &error)) {
    result.error = error;
    return result;
  }

  result.ok = true;
  result.config = config;
  return result;
}

}  // namespace hft
