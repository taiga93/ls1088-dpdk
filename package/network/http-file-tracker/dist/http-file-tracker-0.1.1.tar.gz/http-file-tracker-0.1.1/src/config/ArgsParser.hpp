#pragma once

#include "config/RuntimeConfig.hpp"

namespace hft {

ConfigResult parseArgs(int argc, const char* const argv[]);

}  // namespace hft
