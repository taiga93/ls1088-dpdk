#pragma once

#include "http/HttpTypes.hpp"

#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace hft {

class HttpParser {
 public:
  HttpParser(uint32_t max_header_bytes,
             uint32_t max_uri_bytes,
             uint32_t max_filename_bytes);

  std::vector<HttpMessage> feed(std::string_view bytes, bool from_client);
  void startBody(bool from_client,
                 BodyMode mode,
                 std::optional<uint64_t> declared_size);
  std::vector<BodyProgress> feedBody(std::string_view bytes, bool from_client);
  std::vector<BodyProgress> skipBodyBytes(uint64_t bytes, bool from_client);
  void finishCloseDelimited(bool from_client);
  ParseError lastError() const { return last_error_; }
  void resetError() { last_error_ = ParseError::None; }

 private:
  struct SideState {
    std::string header_buffer;
    BodyMode body_mode = BodyMode::NoBody;
    std::optional<uint64_t> declared_size;
    uint64_t remaining_content_length = 0;
    bool body_active = false;
    bool close_delimited_finished = false;
    std::string chunk_buffer;
    std::string prefetched_body;
  };

  std::vector<HttpMessage> parseSide(SideState& side,
                                     std::string_view bytes,
                                     bool from_client);
  bool parseHeaders(const std::string& raw,
                    bool from_client,
                    HttpMessage* message);

  uint32_t max_header_bytes_;
  uint32_t max_uri_bytes_;
  uint32_t max_filename_bytes_;
  ParseError last_error_ = ParseError::None;
  SideState client_;
  SideState server_;
};

}  // namespace hft
