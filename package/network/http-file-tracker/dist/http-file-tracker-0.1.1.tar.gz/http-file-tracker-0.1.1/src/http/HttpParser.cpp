#include "http/HttpParser.hpp"

#include <algorithm>
#include <cctype>
#include <limits>
#include <sstream>

namespace hft {
namespace {

std::string lower(std::string value) {
  std::transform(value.begin(), value.end(), value.begin(), [](unsigned char ch) {
    return static_cast<char>(std::tolower(ch));
  });
  return value;
}

std::string trim(std::string value) {
  while (!value.empty() && (value.front() == ' ' || value.front() == '\t')) {
    value.erase(value.begin());
  }
  while (!value.empty() &&
         (value.back() == ' ' || value.back() == '\t' || value.back() == '\r')) {
    value.pop_back();
  }
  return value;
}

bool parseUint64Header(const std::string& value, uint64_t* out) {
  if (value.empty()) {
    return false;
  }

  uint64_t result = 0;
  for (char ch : value) {
    if (ch < '0' || ch > '9') {
      return false;
    }
    result = (result * 10) + static_cast<uint64_t>(ch - '0');
  }

  *out = result;
  return true;
}

bool parseHexUint64(const std::string& value, uint64_t* out) {
  if (value.empty()) {
    return false;
  }

  uint64_t result = 0;
  for (char ch : value) {
    uint64_t digit = 0;
    if (ch >= '0' && ch <= '9') {
      digit = static_cast<uint64_t>(ch - '0');
    } else if (ch >= 'a' && ch <= 'f') {
      digit = 10 + static_cast<uint64_t>(ch - 'a');
    } else if (ch >= 'A' && ch <= 'F') {
      digit = 10 + static_cast<uint64_t>(ch - 'A');
    } else {
      return false;
    }

    if (result > (std::numeric_limits<uint64_t>::max() - digit) / 16) {
      return false;
    }
    result = (result * 16) + digit;
  }

  *out = result;
  return true;
}

}  // namespace

HttpParser::HttpParser(uint32_t max_header_bytes,
                       uint32_t max_uri_bytes,
                       uint32_t max_filename_bytes)
    : max_header_bytes_(max_header_bytes),
      max_uri_bytes_(max_uri_bytes),
      max_filename_bytes_(max_filename_bytes) {
  (void)max_filename_bytes_;
}

std::vector<HttpMessage> HttpParser::feed(std::string_view bytes,
                                          bool from_client) {
  return parseSide(from_client ? client_ : server_, bytes, from_client);
}

void HttpParser::startBody(bool from_client,
                           BodyMode mode,
                           std::optional<uint64_t> declared_size) {
  SideState& side = from_client ? client_ : server_;
  side.body_mode = mode;
  side.declared_size = declared_size;
  side.remaining_content_length = declared_size.value_or(0);
  side.body_active = mode != BodyMode::NoBody;
  side.close_delimited_finished = false;
  side.chunk_buffer.clear();
}

void HttpParser::finishCloseDelimited(bool from_client) {
  SideState& side = from_client ? client_ : server_;
  if (side.body_active && side.body_mode == BodyMode::CloseDelimited) {
    side.close_delimited_finished = true;
  }
}

std::vector<BodyProgress> HttpParser::feedBody(std::string_view bytes,
                                               bool from_client) {
  SideState& side = from_client ? client_ : server_;
  std::vector<BodyProgress> progress;
  if (!side.body_active) {
    return progress;
  }

  std::string combined;
  if (!side.prefetched_body.empty()) {
    combined = std::move(side.prefetched_body);
    side.prefetched_body.clear();
  }
  combined.append(bytes.data(), bytes.size());

  if (side.body_mode == BodyMode::ContentLength) {
    const uint64_t available = static_cast<uint64_t>(combined.size());
    const uint64_t taken =
        std::min<uint64_t>(side.remaining_content_length, available);
    side.remaining_content_length -= taken;
    const bool complete = side.remaining_content_length == 0;
    progress.push_back(BodyProgress{taken, complete});
    if (complete) {
      side.body_active = false;
      side.body_mode = BodyMode::NoBody;
      const size_t consumed = static_cast<size_t>(taken);
      if (consumed < combined.size()) {
        side.header_buffer.append(combined.data() + consumed,
                                  combined.size() - consumed);
      }
    }
    return progress;
  }

  if (side.body_mode == BodyMode::CloseDelimited) {
    if (!combined.empty()) {
      progress.push_back(
          BodyProgress{static_cast<uint64_t>(combined.size()), false});
    }
    if (side.close_delimited_finished) {
      side.body_active = false;
      side.body_mode = BodyMode::NoBody;
      progress.push_back(BodyProgress{0, true});
    }
    return progress;
  }

  if (side.body_mode == BodyMode::Chunked) {
    side.chunk_buffer.append(combined.data(), combined.size());
    while (true) {
      const size_t line_end = side.chunk_buffer.find("\r\n");
      if (line_end == std::string::npos) {
        break;
      }

      std::string size_text = side.chunk_buffer.substr(0, line_end);
      const size_t extension = size_text.find(';');
      if (extension != std::string::npos) {
        size_text.resize(extension);
      }

      uint64_t chunk_size = 0;
      if (!parseHexUint64(size_text, &chunk_size)) {
        last_error_ = ParseError::MalformedHeader;
        side.body_active = false;
        side.body_mode = BodyMode::NoBody;
        side.chunk_buffer.clear();
        break;
      }

      const size_t chunk_offset = line_end + 2;
      if (chunk_size == 0) {
        size_t total_consumed = std::string::npos;
        if (side.chunk_buffer.size() >= chunk_offset + 2 &&
            side.chunk_buffer.compare(chunk_offset, 2, "\r\n") == 0) {
          total_consumed = chunk_offset + 2;
        } else {
          const size_t trailer_end = side.chunk_buffer.find("\r\n\r\n", chunk_offset);
          if (trailer_end == std::string::npos) {
            break;
          }
          total_consumed = trailer_end + 4;
        }

        side.chunk_buffer.erase(0, total_consumed);
        side.body_active = false;
        side.body_mode = BodyMode::NoBody;
        if (progress.empty()) {
          progress.push_back(BodyProgress{0, true});
        } else {
          progress.back().complete = true;
        }
        if (!side.chunk_buffer.empty()) {
          side.header_buffer.append(side.chunk_buffer);
          side.chunk_buffer.clear();
        }
        break;
      }

      const uint64_t needed = chunk_size + 2;
      if (needed > static_cast<uint64_t>(std::numeric_limits<size_t>::max())) {
        last_error_ = ParseError::MalformedHeader;
        side.body_active = false;
        side.body_mode = BodyMode::NoBody;
        side.chunk_buffer.clear();
        break;
      }
      const size_t required = chunk_offset + static_cast<size_t>(needed);
      if (side.chunk_buffer.size() < required) {
        break;
      }
      if (side.chunk_buffer.compare(required - 2, 2, "\r\n") != 0) {
        last_error_ = ParseError::MalformedHeader;
        side.body_active = false;
        side.body_mode = BodyMode::NoBody;
        side.chunk_buffer.clear();
        break;
      }

      side.chunk_buffer.erase(0, chunk_offset);
      side.chunk_buffer.erase(0, static_cast<size_t>(chunk_size));
      side.chunk_buffer.erase(0, 2);
      progress.push_back(BodyProgress{chunk_size, false});
    }
  }

  return progress;
}

std::vector<BodyProgress> HttpParser::skipBodyBytes(uint64_t bytes,
                                                    bool from_client) {
  SideState& side = from_client ? client_ : server_;
  std::vector<BodyProgress> progress;
  if (!side.body_active || bytes == 0) {
    return progress;
  }

  if (side.body_mode == BodyMode::ContentLength) {
    const uint64_t taken = std::min<uint64_t>(side.remaining_content_length, bytes);
    side.remaining_content_length -= taken;
    const bool complete = side.remaining_content_length == 0;
    progress.push_back(BodyProgress{taken, complete});
    if (complete) {
      side.body_active = false;
      side.body_mode = BodyMode::NoBody;
    }
    return progress;
  }

  if (side.body_mode == BodyMode::CloseDelimited) {
    progress.push_back(BodyProgress{bytes, false});
  }
  return progress;
}

std::vector<HttpMessage> HttpParser::parseSide(SideState& side,
                                               std::string_view bytes,
                                               bool from_client) {
  std::vector<HttpMessage> messages;
  if (side.body_active) {
    side.prefetched_body.append(bytes.data(), bytes.size());
    return messages;
  }

  side.header_buffer.append(bytes.data(), bytes.size());
  if (side.header_buffer.size() > max_header_bytes_) {
    last_error_ = ParseError::HeaderLimit;
    side.header_buffer.clear();
    return messages;
  }

  size_t header_end = std::string::npos;
  while ((header_end = side.header_buffer.find("\r\n\r\n")) != std::string::npos) {
    const std::string raw = side.header_buffer.substr(0, header_end + 4);
    side.header_buffer.erase(0, header_end + 4);

    HttpMessage message;
    if (parseHeaders(raw, from_client, &message)) {
      messages.push_back(message);
      if (message.body_mode != BodyMode::NoBody && !side.header_buffer.empty()) {
        side.prefetched_body.append(side.header_buffer);
        side.header_buffer.clear();
        break;
      }
    }
  }

  return messages;
}

bool HttpParser::parseHeaders(const std::string& raw,
                              bool from_client,
                              HttpMessage* message) {
  std::istringstream input(raw);
  std::string line;
  if (!std::getline(input, line)) {
    last_error_ = ParseError::MalformedStartLine;
    return false;
  }
  if (!line.empty() && line.back() == '\r') {
    line.pop_back();
  }

  message->is_request = from_client;
  if (from_client) {
    std::istringstream start(line);
    std::string version;
    if (!(start >> message->method >> message->uri >> version) ||
        version.rfind("HTTP/", 0) != 0) {
      last_error_ = ParseError::MalformedStartLine;
      return false;
    }
    if (message->uri.size() > max_uri_bytes_) {
      message->uri.resize(max_uri_bytes_);
    }
  } else {
    std::istringstream start(line);
    std::string version;
    if (!(start >> version >> message->status_code) ||
        version.rfind("HTTP/", 0) != 0) {
      last_error_ = ParseError::MalformedStartLine;
      return false;
    }
  }

  while (std::getline(input, line)) {
    if (line == "\r" || line.empty()) {
      break;
    }
    if (!line.empty() && line.back() == '\r') {
      line.pop_back();
    }

    const auto colon = line.find(':');
    if (colon == std::string::npos) {
      last_error_ = ParseError::MalformedHeader;
      return false;
    }

    const std::string key = lower(trim(line.substr(0, colon)));
    const std::string value = trim(line.substr(colon + 1));
    message->headers[key] = value;
  }

  const auto content_length = message->headers.find("content-length");
  const auto transfer_encoding = message->headers.find("transfer-encoding");
  if (transfer_encoding != message->headers.end() &&
      lower(transfer_encoding->second).find("chunked") != std::string::npos) {
    message->body_mode = BodyMode::Chunked;
  } else if (content_length != message->headers.end()) {
    uint64_t length = 0;
    if (parseUint64Header(content_length->second, &length) && length > 0) {
      message->body_mode = BodyMode::ContentLength;
      message->declared_body_size = length;
    }
  }

  const auto content_type = message->headers.find("content-type");
  if (content_type != message->headers.end()) {
    message->content_type = content_type->second;
  }

  const auto disposition = message->headers.find("content-disposition");
  if (disposition != message->headers.end()) {
    message->content_disposition = disposition->second;
  }

  const auto upgrade = message->headers.find("upgrade");
  if (upgrade != message->headers.end() && lower(upgrade->second) == "h2c") {
    message->h2c_upgrade = true;
  }

  message->headers_complete = true;
  return true;
}

}  // namespace hft
