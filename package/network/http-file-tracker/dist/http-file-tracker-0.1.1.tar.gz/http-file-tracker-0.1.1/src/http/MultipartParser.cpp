#include "http/MultipartParser.hpp"

#include <algorithm>
#include <cctype>
#include <sstream>
#include <utility>

namespace hft {
namespace {

std::string lower(std::string value) {
  std::transform(value.begin(), value.end(), value.begin(), [](unsigned char ch) {
    return static_cast<char>(std::tolower(ch));
  });
  return value;
}

std::string trim(std::string value) {
  while (!value.empty() &&
         (value.front() == ' ' || value.front() == '\t' || value.front() == '\r')) {
    value.erase(value.begin());
  }
  while (!value.empty() &&
         (value.back() == ' ' || value.back() == '\t' || value.back() == '\r')) {
    value.pop_back();
  }
  return value;
}

std::string extractQuotedParam(const std::string& header, const std::string& name) {
  const std::string key = name + "=\"";
  const size_t pos = header.find(key);
  if (pos == std::string::npos) {
    return "";
  }

  const size_t start = pos + key.size();
  const size_t end = header.find('"', start);
  if (end == std::string::npos) {
    return "";
  }
  return header.substr(start, end - start);
}

}  // namespace

std::string multipartBoundaryFromContentType(const std::string& content_type) {
  const std::string key = "boundary=";
  const size_t pos = content_type.find(key);
  if (pos == std::string::npos) {
    return "";
  }

  std::string boundary = content_type.substr(pos + key.size());
  const size_t separator = boundary.find(';');
  if (separator != std::string::npos) {
    boundary.resize(separator);
  }
  boundary = trim(boundary);

  if (!boundary.empty() && boundary.front() == '"') {
    boundary.erase(boundary.begin());
    const size_t end_quote = boundary.find('"');
    if (end_quote != std::string::npos) {
      boundary.resize(end_quote);
    }
  }

  return boundary;
}

MultipartParser::MultipartParser(std::string boundary,
                                 uint32_t max_header_bytes,
                                 uint32_t max_filename_bytes)
    : boundary_marker_("--" + std::move(boundary)),
      body_boundary_marker_("\r\n" + boundary_marker_),
      max_header_bytes_(max_header_bytes),
      max_filename_bytes_(max_filename_bytes) {}

bool MultipartParser::parsePartHeaders(const std::string& raw_headers,
                                       std::string* filename,
                                       std::string* content_type,
                                       std::string* error_reason) {
  if (raw_headers.size() > max_header_bytes_) {
    *error_reason = "header_limit";
    return false;
  }

  std::istringstream input(raw_headers);
  std::string line;
  while (std::getline(input, line)) {
    if (!line.empty() && line.back() == '\r') {
      line.pop_back();
    }

    const size_t colon = line.find(':');
    if (colon == std::string::npos) {
      continue;
    }

    const std::string key = lower(line.substr(0, colon));
    const std::string value = trim(line.substr(colon + 1));
    if (key == "content-disposition") {
      *filename = extractQuotedParam(value, "filename");
      if (filename->size() > max_filename_bytes_) {
        filename->resize(max_filename_bytes_);
      }
    } else if (key == "content-type") {
      *content_type = value;
    }
  }

  return true;
}

std::vector<MultipartEvent> MultipartParser::fail(const std::string& reason) {
  state_ = State::Failed;
  buffer_.clear();
  return finishPartial(reason);
}

void MultipartParser::resetCurrentPart() {
  current_part_is_file_ = false;
  current_filename_.clear();
  current_content_type_.clear();
  current_bytes_ = 0;
}

std::vector<MultipartEvent> MultipartParser::feed(std::string_view bytes) {
  std::vector<MultipartEvent> events;
  if (state_ == State::Done || state_ == State::Failed) {
    return events;
  }

  buffer_.append(bytes.data(), bytes.size());

  while (true) {
    if (state_ == State::ExpectBoundary) {
      const size_t marker = buffer_.find(boundary_marker_);
      if (marker == std::string::npos) {
        const size_t keep = boundary_marker_.size();
        if (buffer_.size() > keep) {
          buffer_.erase(0, buffer_.size() - keep);
        }
        break;
      }

      if (marker != 0) {
        buffer_.erase(0, marker);
      }

      const size_t after_marker = boundary_marker_.size();
      if (buffer_.size() < after_marker + 2) {
        break;
      }

      if (buffer_.compare(after_marker, 2, "--") == 0) {
        buffer_.erase(0, after_marker + 2);
        if (buffer_.size() >= 2 && buffer_.compare(0, 2, "\r\n") == 0) {
          buffer_.erase(0, 2);
        }
        state_ = State::Done;
        break;
      }

      if (buffer_.compare(after_marker, 2, "\r\n") != 0) {
        return fail("malformed_boundary");
      }

      buffer_.erase(0, after_marker + 2);
      state_ = State::ExpectHeaders;
      continue;
    }

    if (state_ == State::ExpectHeaders) {
      const size_t header_end = buffer_.find("\r\n\r\n");
      if (header_end == std::string::npos) {
        if (buffer_.size() > max_header_bytes_ + 4) {
          return fail("header_limit");
        }
        break;
      }

      std::string filename;
      std::string content_type;
      std::string error_reason;
      if (!parsePartHeaders(buffer_.substr(0, header_end), &filename,
                            &content_type, &error_reason)) {
        return fail(error_reason);
      }

      buffer_.erase(0, header_end + 4);
      current_part_is_file_ = !filename.empty();
      current_filename_ = std::move(filename);
      current_content_type_ = std::move(content_type);
      current_bytes_ = 0;
      if (current_part_is_file_) {
        events.push_back(MultipartEvent{MultipartEventType::FileStart,
                                        current_filename_,
                                        current_content_type_,
                                        0,
                                        ""});
      }
      state_ = State::ExpectBody;
      continue;
    }

    if (state_ == State::ExpectBody) {
      const size_t boundary = buffer_.find(body_boundary_marker_);
      if (boundary != std::string::npos) {
        if (current_part_is_file_) {
          current_bytes_ += static_cast<uint64_t>(boundary);
          events.push_back(MultipartEvent{MultipartEventType::FileEnd,
                                          current_filename_,
                                          current_content_type_,
                                          current_bytes_,
                                          ""});
        }

        buffer_.erase(0, boundary + 2);
        resetCurrentPart();
        state_ = State::ExpectBoundary;
        continue;
      }

      const size_t keep = body_boundary_marker_.size() > 0
                              ? body_boundary_marker_.size() - 1
                              : 0;
      if (buffer_.size() <= keep) {
        break;
      }

      const size_t committed = buffer_.size() - keep;
      if (current_part_is_file_) {
        current_bytes_ += static_cast<uint64_t>(committed);
      }
      buffer_.erase(0, committed);
      break;
    }

    break;
  }

  return events;
}

std::vector<MultipartEvent> MultipartParser::finishPartial(const std::string& reason) {
  std::vector<MultipartEvent> events;
  if (!current_part_is_file_) {
    return events;
  }

  events.push_back(MultipartEvent{MultipartEventType::ParserError,
                                  current_filename_,
                                  current_content_type_,
                                  current_bytes_,
                                  reason});
  resetCurrentPart();
  return events;
}

}  // namespace hft
