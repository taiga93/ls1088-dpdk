#pragma once

#include <cstdint>
#include <map>
#include <optional>
#include <ostream>
#include <string>
#include <vector>

namespace hft {

enum class TransferKind { FileDetected, BodyTransfer };
enum class TransferStatus { Complete, Partial, Timeout, Unsupported };
enum class Direction { Upload, Download, LanUpload, LanDownload };

struct TransferEvent {
  TransferKind kind = TransferKind::BodyTransfer;
  TransferStatus status = TransferStatus::Complete;
  Direction direction = Direction::Download;
  std::string reason;
  std::string client_ip;
  std::string peer_ip;
  std::string host;
  std::string uri;
  std::string filename = "unknown";
  std::string content_type;
  uint64_t bytes_transferred = 0;
  std::optional<uint64_t> declared_size;
  std::string start_ts;
  std::string end_ts;
  uint64_t duration_ms = 0;
  std::string confidence = "low";
  std::vector<std::string> truncated_fields;
};

enum class BodyMode { NoBody, ContentLength, Chunked, CloseDelimited };
enum class ParseError {
  None,
  HeaderLimit,
  MalformedStartLine,
  MalformedHeader,
  UnsupportedH2c,
};

struct HttpMessage {
  bool is_request = true;
  bool headers_complete = false;
  bool h2c_upgrade = false;
  std::string method;
  std::string uri;
  int status_code = 0;
  std::map<std::string, std::string> headers;
  BodyMode body_mode = BodyMode::NoBody;
  std::optional<uint64_t> declared_body_size;
  std::string content_type;
  std::string content_disposition;
};

struct BodyProgress {
  uint64_t bytes = 0;
  bool complete = false;
};

inline std::ostream& operator<<(std::ostream& out, BodyMode mode) {
  switch (mode) {
    case BodyMode::NoBody:
      return out << "NoBody";
    case BodyMode::ContentLength:
      return out << "ContentLength";
    case BodyMode::Chunked:
      return out << "Chunked";
    case BodyMode::CloseDelimited:
      return out << "CloseDelimited";
  }
  return out << "BodyMode(?)";
}

inline std::ostream& operator<<(std::ostream& out, ParseError error) {
  switch (error) {
    case ParseError::None:
      return out << "None";
    case ParseError::HeaderLimit:
      return out << "HeaderLimit";
    case ParseError::MalformedStartLine:
      return out << "MalformedStartLine";
    case ParseError::MalformedHeader:
      return out << "MalformedHeader";
    case ParseError::UnsupportedH2c:
      return out << "UnsupportedH2c";
  }
  return out << "ParseError(?)";
}

}  // namespace hft
