#pragma once

#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace hft {

enum class MultipartEventType { FileStart, FileData, FileEnd, ParserError };

struct MultipartEvent {
  MultipartEventType type = MultipartEventType::ParserError;
  std::string filename;
  std::string content_type;
  uint64_t bytes = 0;
  std::string reason;
};

class MultipartParser {
 public:
  MultipartParser(std::string boundary,
                  uint32_t max_header_bytes,
                  uint32_t max_filename_bytes);

  std::vector<MultipartEvent> feed(std::string_view bytes);
  std::vector<MultipartEvent> finishPartial(const std::string& reason);

 private:
  enum class State { ExpectBoundary, ExpectHeaders, ExpectBody, Done, Failed };

  bool parsePartHeaders(const std::string& raw_headers,
                        std::string* filename,
                        std::string* content_type,
                        std::string* error_reason);

  std::vector<MultipartEvent> fail(const std::string& reason);
  void resetCurrentPart();

  std::string boundary_marker_;
  std::string body_boundary_marker_;
  uint32_t max_header_bytes_ = 0;
  uint32_t max_filename_bytes_ = 0;
  std::string buffer_;
  State state_ = State::ExpectBoundary;
  bool current_part_is_file_ = false;
  std::string current_filename_;
  std::string current_content_type_;
  uint64_t current_bytes_ = 0;
};

std::string multipartBoundaryFromContentType(const std::string& content_type);

}  // namespace hft
