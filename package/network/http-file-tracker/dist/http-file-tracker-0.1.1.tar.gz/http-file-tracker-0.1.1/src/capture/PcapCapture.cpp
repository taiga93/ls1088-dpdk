#include "capture/PcapCapture.hpp"

#include "config/RuntimeConfig.hpp"
#include "core/Clock.hpp"

#include <IPv4Layer.h>
#include <IPv6Layer.h>
#include <PcapLiveDevice.h>
#include <PcapLiveDeviceList.h>
#include <Packet.h>
#include <TcpLayer.h>

#include <arpa/inet.h>

#include <atomic>
#include <chrono>
#include <mutex>
#include <memory>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>

namespace hft {

class PcapCapture::Impl {
 public:
  Impl(RuntimeConfig config, Logger& logger)
      : config_(std::move(config)), logger_(logger), flow_tracker_(config_, logger_) {}

  bool start(std::string* error) {
    const std::string filter = buildBpfFilter(config_);
    for (const auto& name : config_.interfaces) {
      auto* device = pcpp::PcapLiveDeviceList::getInstance().getPcapLiveDeviceByName(name);
      if (device == nullptr) {
        stop();
        if (error != nullptr) {
          *error = "capture interface not found: " + name;
        }
        return false;
      }
      pcpp::PcapLiveDevice::DeviceConfiguration device_config(
          pcpp::PcapLiveDevice::Promiscuous,
          20,
          0,
          pcpp::PcapLiveDevice::PCPP_INOUT,
          static_cast<int>(config_.capture_snaplen));
      if (!device->open(device_config)) {
        stop();
        if (error != nullptr) {
          *error = "failed to open interface: " + name;
        }
        return false;
      }
      if (!device->setFilter(filter)) {
        device->close();
        stop();
        if (error != nullptr) {
          *error = "failed to set BPF filter on: " + name;
        }
        return false;
      }
      devices_.push_back(device);
    }

    running_ = true;
    for (auto* device : devices_) {
      device->startCapture(&Impl::onPacketArrives, this);
    }
    cleanup_thread_ = std::thread(&Impl::cleanupLoop, this);
    return true;
  }

  void stop() {
    running_ = false;
    if (cleanup_thread_.joinable()) {
      cleanup_thread_.join();
    }
    for (auto* device : devices_) {
      device->stopCapture();
      device->close();
    }
    devices_.clear();
  }

  static void onPacketArrives(pcpp::RawPacket* raw_packet,
                              pcpp::PcapLiveDevice*,
                              void* user_cookie) {
    auto* self = static_cast<Impl*>(user_cookie);
    if (!self->running_) {
      return;
    }

    pcpp::Packet packet(raw_packet);
    auto* tcp = packet.getLayerOfType<pcpp::TcpLayer>();
    if (tcp == nullptr) {
      return;
    }

    auto* ipv4 = packet.getLayerOfType<pcpp::IPv4Layer>();
    auto* ipv6 = packet.getLayerOfType<pcpp::IPv6Layer>();
    std::string src_ip;
    std::string dst_ip;
    if (ipv4 != nullptr) {
      src_ip = ipv4->getSrcIPv4Address().toString();
      dst_ip = ipv4->getDstIPv4Address().toString();
    } else if (ipv6 != nullptr) {
      src_ip = ipv6->getSrcIPv6Address().toString();
      dst_ip = ipv6->getDstIPv6Address().toString();
    } else {
      return;
    }

    Endpoint src{src_ip, tcp->getSrcPort()};
    Endpoint dst{dst_ip, tcp->getDstPort()};
    const auto key = canonicalFlowKey(src, dst);
    const auto* tcp_header = tcp->getTcpHeader();
    const bool fin_closes_flow = tcp_header->finFlag != 0;
    const bool rst_closes_flow = tcp_header->rstFlag != 0;
    const bool closes_flow = fin_closes_flow || rst_closes_flow;
    const uint32_t sequence = ntohl(tcp_header->sequenceNumber);
    const uint8_t* payload = tcp->getLayerPayload();
    const size_t payload_len = tcp->getLayerPayloadSize();
    if ((payload == nullptr || payload_len == 0) && !closes_flow) {
      return;
    }

    const std::string now_ts = currentTimestampUtc();
    std::lock_guard<std::mutex> lock(self->flow_tracker_mutex_);
    if (payload != nullptr && payload_len > 0) {
      self->flow_tracker_.onTcpData(
          key,
          src,
          dst,
          std::string_view(reinterpret_cast<const char*>(payload), payload_len),
          now_ts,
          sequence);
    }
    if (fin_closes_flow) {
      const uint32_t close_sequence =
          sequence + static_cast<uint32_t>(payload_len);
      self->flow_tracker_.onTcpClose(key, src, now_ts, close_sequence);
    } else if (rst_closes_flow) {
      self->flow_tracker_.onTcpClose(key, src, now_ts);
    }
  }

 private:
  void cleanupLoop() {
    while (running_) {
      std::this_thread::sleep_for(std::chrono::seconds(1));
      if (!running_) {
        break;
      }

      std::lock_guard<std::mutex> lock(flow_tracker_mutex_);
      flow_tracker_.cleanupIdle(currentTimestampUtc());
    }
  }

  RuntimeConfig config_;
  Logger& logger_;
  FlowTracker flow_tracker_;
  std::mutex flow_tracker_mutex_;
  std::thread cleanup_thread_;
  std::atomic<bool> running_{false};
  std::vector<pcpp::PcapLiveDevice*> devices_;
};

PcapCapture::PcapCapture(RuntimeConfig config, Logger& logger)
    : impl_(std::make_unique<Impl>(std::move(config), logger)) {}

PcapCapture::~PcapCapture() {
  stop();
}

bool PcapCapture::supportedAtBuildTime() {
  return true;
}

bool PcapCapture::start(std::string* error) {
  return impl_->start(error);
}

void PcapCapture::stop() {
  if (impl_) {
    impl_->stop();
  }
}

}  // namespace hft
