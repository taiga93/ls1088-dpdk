#pragma once

#include "config/RuntimeConfig.hpp"
#include "flow/FlowTracker.hpp"
#include "log/Logger.hpp"

#include <memory>
#include <string>
#include <vector>

namespace hft {

class PcapCapture {
 public:
  PcapCapture(RuntimeConfig config, Logger& logger);
  ~PcapCapture();

  static bool supportedAtBuildTime();
  bool start(std::string* error);
  void stop();

 private:
  class Impl;
  std::unique_ptr<Impl> impl_;
};

}  // namespace hft
