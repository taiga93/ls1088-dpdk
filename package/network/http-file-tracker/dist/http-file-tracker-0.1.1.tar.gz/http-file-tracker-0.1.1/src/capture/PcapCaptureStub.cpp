#include "capture/PcapCapture.hpp"

#include <utility>

namespace hft {

class PcapCapture::Impl {
 public:
  Impl(RuntimeConfig, Logger&) {}

  bool start(std::string* error) {
    if (error != nullptr) {
      *error = "PcapPlusPlus capture disabled at build time";
    }
    return false;
  }

  void stop() {}
};

PcapCapture::PcapCapture(RuntimeConfig config, Logger& logger)
    : impl_(std::make_unique<Impl>(std::move(config), logger)) {}

PcapCapture::~PcapCapture() {
  stop();
}

bool PcapCapture::supportedAtBuildTime() {
  return false;
}

bool PcapCapture::start(std::string* error) {
  return impl_->start(error);
}

void PcapCapture::stop() {
  if (impl_) {
    impl_->stop();
  }
}

}  // namespace hft
