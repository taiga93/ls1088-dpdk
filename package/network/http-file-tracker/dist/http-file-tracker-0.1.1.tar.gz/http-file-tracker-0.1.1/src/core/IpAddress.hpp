#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace hft {

enum class AddressFamily { IPv4, IPv6 };

struct ParsedIp {
  AddressFamily family;
  std::array<uint8_t, 16> bytes{};
};

class IpMatcher {
 public:
  bool addPattern(const std::string& pattern, std::string* error);
  bool matches(const std::string& ip) const;
  bool empty() const { return entries_.empty(); }

 private:
  struct Entry {
    ParsedIp network;
    uint8_t prefix_bits = 0;
  };

  std::vector<Entry> entries_;
};

bool parseIpLiteral(const std::string& value, ParsedIp* out);
bool parseIpPattern(const std::string& pattern,
                    ParsedIp* network,
                    uint8_t* prefix_bits,
                    std::string* error);
bool ipMatchesPrefix(const ParsedIp& ip,
                     const ParsedIp& network,
                     uint8_t prefix_bits);

}  // namespace hft
