#include "core/IpAddress.hpp"

#include <arpa/inet.h>

#include <algorithm>
#include <cstring>

namespace hft {
namespace {

uint8_t maxPrefix(AddressFamily family) {
  return family == AddressFamily::IPv4 ? 32 : 128;
}

void maskHostBits(ParsedIp* ip, uint8_t prefix_bits) {
  const uint8_t total_bits = maxPrefix(ip->family);
  for (uint8_t bit = prefix_bits; bit < total_bits; ++bit) {
    const uint8_t byte_index = bit / 8;
    const uint8_t bit_in_byte = 7 - (bit % 8);
    ip->bytes[byte_index] &= static_cast<uint8_t>(~(1u << bit_in_byte));
  }
}

}  // namespace

bool parseIpLiteral(const std::string& value, ParsedIp* out) {
  ParsedIp parsed;
  in_addr ipv4{};
  if (inet_pton(AF_INET, value.c_str(), &ipv4) == 1) {
    parsed.family = AddressFamily::IPv4;
    std::memcpy(parsed.bytes.data(), &ipv4, 4);
    *out = parsed;
    return true;
  }

  in6_addr ipv6{};
  if (inet_pton(AF_INET6, value.c_str(), &ipv6) == 1) {
    parsed.family = AddressFamily::IPv6;
    std::memcpy(parsed.bytes.data(), &ipv6, 16);
    *out = parsed;
    return true;
  }

  return false;
}

bool parseIpPattern(const std::string& pattern,
                    ParsedIp* network,
                    uint8_t* prefix_bits,
                    std::string* error) {
  const auto slash = pattern.find('/');
  const std::string ip_part =
      slash == std::string::npos ? pattern : pattern.substr(0, slash);

  ParsedIp parsed;
  if (!parseIpLiteral(ip_part, &parsed)) {
    if (error) {
      *error = "invalid IP literal: " + pattern;
    }
    return false;
  }

  uint8_t prefix = maxPrefix(parsed.family);
  if (slash != std::string::npos) {
    const std::string prefix_part = pattern.substr(slash + 1);
    if (prefix_part.empty()) {
      if (error) {
        *error = "empty CIDR prefix: " + pattern;
      }
      return false;
    }

    size_t parsed_chars = 0;
    int value = -1;
    try {
      value = std::stoi(prefix_part, &parsed_chars, 10);
    } catch (...) {
      if (error) {
        *error = "invalid CIDR prefix: " + pattern;
      }
      return false;
    }

    if (parsed_chars != prefix_part.size() || value < 0 ||
        value > maxPrefix(parsed.family)) {
      if (error) {
        *error = "CIDR prefix out of range: " + pattern;
      }
      return false;
    }
    prefix = static_cast<uint8_t>(value);
  }

  maskHostBits(&parsed, prefix);
  *network = parsed;
  *prefix_bits = prefix;
  return true;
}

bool ipMatchesPrefix(const ParsedIp& ip,
                     const ParsedIp& network,
                     uint8_t prefix_bits) {
  if (ip.family != network.family) {
    return false;
  }

  const uint8_t total_bits = maxPrefix(ip.family);
  if (prefix_bits > total_bits) {
    return false;
  }

  for (uint8_t bit = 0; bit < prefix_bits; ++bit) {
    const uint8_t byte_index = bit / 8;
    const uint8_t bit_in_byte = 7 - (bit % 8);
    const uint8_t mask = static_cast<uint8_t>(1u << bit_in_byte);
    if ((ip.bytes[byte_index] & mask) != (network.bytes[byte_index] & mask)) {
      return false;
    }
  }
  return true;
}

bool IpMatcher::addPattern(const std::string& pattern, std::string* error) {
  ParsedIp network;
  uint8_t prefix = 0;
  if (!parseIpPattern(pattern, &network, &prefix, error)) {
    return false;
  }

  entries_.push_back(Entry{network, prefix});
  return true;
}

bool IpMatcher::matches(const std::string& ip) const {
  ParsedIp parsed;
  if (!parseIpLiteral(ip, &parsed)) {
    return false;
  }

  return std::any_of(entries_.begin(), entries_.end(), [&](const Entry& entry) {
    return ipMatchesPrefix(parsed, entry.network, entry.prefix_bits);
  });
}

}  // namespace hft
