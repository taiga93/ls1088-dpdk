#pragma once

#include <chrono>
#include <cstdio>
#include <ctime>
#include <optional>
#include <string>
#include <string_view>

namespace hft {

inline std::optional<std::time_t> parseUtcTimestamp(std::string_view value) {
  int year = 0;
  int month = 0;
  int day = 0;
  int hour = 0;
  int minute = 0;
  int second = 0;
  char suffix = '\0';

  if (std::sscanf(value.data(),
                  "%d-%d-%dT%d:%d:%d%c",
                  &year,
                  &month,
                  &day,
                  &hour,
                  &minute,
                  &second,
                  &suffix) != 7 ||
      suffix != 'Z') {
    return std::nullopt;
  }

  std::tm tm{};
  tm.tm_year = year - 1900;
  tm.tm_mon = month - 1;
  tm.tm_mday = day;
  tm.tm_hour = hour;
  tm.tm_min = minute;
  tm.tm_sec = second;
  tm.tm_isdst = 0;

  return timegm(&tm);
}

inline std::optional<uint64_t> elapsedSeconds(std::string_view earlier,
                                              std::string_view later) {
  const auto earlier_ts = parseUtcTimestamp(earlier);
  const auto later_ts = parseUtcTimestamp(later);
  if (!earlier_ts || !later_ts || *later_ts < *earlier_ts) {
    return std::nullopt;
  }

  return static_cast<uint64_t>(*later_ts - *earlier_ts);
}

inline std::string currentTimestampUtc() {
  const auto now = std::chrono::system_clock::now();
  const std::time_t now_time = std::chrono::system_clock::to_time_t(now);
  std::tm utc_tm{};
  gmtime_r(&now_time, &utc_tm);

  char buffer[32];
  std::snprintf(buffer,
                sizeof(buffer),
                "%04d-%02d-%02dT%02d:%02d:%02dZ",
                utc_tm.tm_year + 1900,
                utc_tm.tm_mon + 1,
                utc_tm.tm_mday,
                utc_tm.tm_hour,
                utc_tm.tm_min,
                utc_tm.tm_sec);
  return buffer;
}

}  // namespace hft
