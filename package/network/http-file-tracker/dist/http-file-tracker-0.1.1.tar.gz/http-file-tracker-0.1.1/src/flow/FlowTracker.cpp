#include "flow/FlowTracker.hpp"

#include "core/Clock.hpp"

#include <cstdint>
#include <optional>
#include <tuple>
#include <utility>

namespace hft {
namespace {

constexpr size_t kMaxPendingSequenceBytes = 32 * 1024 * 1024;

bool sameEndpoint(const Endpoint& left, const Endpoint& right) {
  return left.ip == right.ip && left.port == right.port;
}

bool isKnownMethod(std::string_view method) {
  return method == "GET" || method == "POST" || method == "PUT" ||
         method == "PATCH" || method == "DELETE" || method == "HEAD" ||
         method == "OPTIONS";
}

bool looksLikeHttpRequestLine(std::string_view bytes) {
  const size_t line_end = bytes.find("\r\n");
  if (line_end == std::string_view::npos) {
    return false;
  }

  const std::string_view line = bytes.substr(0, line_end);
  const size_t method_end = line.find(' ');
  if (method_end == std::string_view::npos || !isKnownMethod(line.substr(0, method_end))) {
    return false;
  }

  const size_t uri_end = line.find(' ', method_end + 1);
  if (uri_end == std::string_view::npos || uri_end == method_end + 1) {
    return false;
  }

  return line.substr(uri_end + 1).rfind("HTTP/", 0) == 0;
}

FlowTracker::ParserSideState& sideStateFor(FlowTracker::FlowState& flow,
                                           const FlowKey& key,
                                           const Endpoint& endpoint) {
  if (sameEndpoint(endpoint, key.a)) {
    return flow.endpoint_a;
  }
  return flow.endpoint_b;
}

struct SequenceBytes {
  std::string_view immediate;
  std::string pending;
  uint64_t skipped = 0;
};

void storePendingSegment(FlowTracker::ParserSideState& side,
                         uint32_t sequence,
                         std::string_view bytes) {
  if (bytes.empty()) {
    return;
  }

  std::string segment(bytes);
  auto existing = side.pending_segments.find(sequence);
  if (existing != side.pending_segments.end() &&
      existing->second.size() >= segment.size()) {
    return;
  }

  if (existing != side.pending_segments.end()) {
    side.pending_sequence_bytes -= existing->second.size();
  }
  side.pending_sequence_bytes += segment.size();
  side.pending_segments[sequence] = std::move(segment);
  if (side.pending_sequence_bytes > kMaxPendingSequenceBytes) {
    side.pending_segments.clear();
    side.pending_sequence_bytes = 0;
  }
}

std::string drainContiguousBytes(FlowTracker::ParserSideState& side) {
  std::string result;
  while (side.next_sequence) {
    auto it = side.pending_segments.upper_bound(*side.next_sequence);
    if (it == side.pending_segments.begin()) {
      break;
    }
    --it;

    const uint32_t segment_sequence = it->first;
    const std::string& segment = it->second;
    const size_t offset =
        static_cast<size_t>(*side.next_sequence - segment_sequence);
    if (offset >= segment.size()) {
      side.pending_sequence_bytes -= segment.size();
      side.pending_segments.erase(it);
      continue;
    }

    result.append(segment.data() + offset, segment.size() - offset);
    side.next_sequence =
        *side.next_sequence + static_cast<uint32_t>(segment.size() - offset);
    side.pending_sequence_bytes -= segment.size();
    side.pending_segments.erase(it);
  }
  return result;
}

SequenceBytes sequenceFilteredBytes(FlowTracker::ParserSideState& side,
                                    std::string_view bytes,
                                    std::optional<uint32_t> sequence,
                                    bool skip_gaps) {
  if (!sequence) {
    return SequenceBytes{bytes, "", 0};
  }

  if (!side.next_sequence) {
    side.next_sequence = *sequence;
  }

  const int32_t distance =
      static_cast<int32_t>(*sequence - *side.next_sequence);
  if (distance > 0) {
    if (skip_gaps) {
      const uint64_t skipped = static_cast<uint64_t>(distance);
      side.next_sequence =
          *side.next_sequence + static_cast<uint32_t>(skipped);
      side.next_sequence =
          *side.next_sequence + static_cast<uint32_t>(bytes.size());
      return SequenceBytes{bytes, drainContiguousBytes(side), skipped};
    }
    storePendingSegment(side, *sequence, bytes);
    return SequenceBytes{{}, "", 0};
  }

  if (distance < 0) {
    const size_t offset = static_cast<size_t>(*side.next_sequence - *sequence);
    if (offset >= bytes.size()) {
      return SequenceBytes{{}, drainContiguousBytes(side), 0};
    }
    bytes = bytes.substr(offset);
  }

  side.next_sequence =
      *side.next_sequence + static_cast<uint32_t>(bytes.size());
  return SequenceBytes{bytes, drainContiguousBytes(side), 0};
}

void emitUnsupportedH2c(Logger& logger,
                        const Endpoint& src,
                        const Endpoint& dst,
                        bool from_client,
                        const std::string& now_ts) {
  TransferEvent event;
  event.status = TransferStatus::Unsupported;
  event.direction = from_client ? Direction::Upload : Direction::Download;
  event.reason = "h2c";
  event.client_ip = from_client ? src.ip : dst.ip;
  event.peer_ip = from_client ? dst.ip : src.ip;
  event.host = event.peer_ip;
  event.start_ts = now_ts;
  event.end_ts = now_ts;
  logger.logTransfer(event);
}

void emitProgressEvents(FlowTracker::FlowState& flow,
                        FlowTracker::ParserSideState& side,
                        bool from_client,
                        const std::vector<BodyProgress>& progress,
                        const std::string& now_ts,
                        Logger& logger) {
  for (const BodyProgress& item : progress) {
    const auto events = flow.detector.onBodyProgress(from_client, item, now_ts);
    for (const auto& event : events) {
      logger.logTransfer(event);
    }
    if (item.complete) {
      side.body_active = false;
      side.multipart = false;
      side.body_mode = BodyMode::NoBody;
    }
  }
}

void emitMultipartEvents(FlowTracker::FlowState& flow,
                         std::string_view raw_bytes,
                         const std::string& now_ts,
                         Logger& logger) {
  if (raw_bytes.empty()) {
    return;
  }

  const auto events = flow.detector.onMultipartBytes(raw_bytes, now_ts);
  for (const auto& event : events) {
    logger.logTransfer(event);
  }
}

void processPayloadBytes(FlowTracker::FlowState& flow,
                         FlowTracker::ParserSideState& side,
                         bool from_client,
                         std::string_view bytes,
                         const std::string& now_ts,
                         Logger& logger) {
  if (side.multipart && from_client) {
    emitMultipartEvents(flow, bytes, now_ts, logger);
  }
  emitProgressEvents(flow,
                     side,
                     from_client,
                     flow.parser.feedBody(bytes, from_client),
                     now_ts,
                     logger);
}

void processSkippedPayloadBytes(FlowTracker::FlowState& flow,
                                FlowTracker::ParserSideState& side,
                                bool from_client,
                                uint64_t bytes,
                                const std::string& now_ts,
                                Logger& logger) {
  emitProgressEvents(flow,
                     side,
                     from_client,
                     flow.parser.skipBodyBytes(bytes, from_client),
                     now_ts,
                     logger);
}

void logParserError(HttpParser& parser, Logger& logger) {
  if (parser.lastError() == ParseError::None) {
    return;
  }

  logger.logWarning("flow_tracker_parse_error");
  parser.resetError();
}

void processSegment(FlowTracker::FlowState& flow,
                    FlowTracker::ParserSideState& side,
                    const Endpoint& src,
                    const Endpoint& dst,
                    bool from_client,
                    std::string_view bytes,
                    const std::string& now_ts,
                    Logger& logger) {
  if (side.body_active) {
    processPayloadBytes(flow, side, from_client, bytes, now_ts, logger);
    logParserError(flow.parser, logger);
    return;
  }

  side.undecided_bytes.append(bytes.data(), bytes.size());
  const auto messages = flow.parser.feed(bytes, from_client);
  logParserError(flow.parser, logger);

  for (const HttpMessage& message : messages) {
    const size_t header_end = side.undecided_bytes.find("\r\n\r\n");
    if (header_end == std::string::npos) {
      side.undecided_bytes.clear();
      return;
    }

    const size_t after_headers = header_end + 4;
    if (message.h2c_upgrade) {
      emitUnsupportedH2c(logger, src, dst, from_client, now_ts);
    } else {
      flow.detector.onHttpMessage(src, dst, message, from_client);
    }

    if (message.body_mode == BodyMode::NoBody) {
      side.undecided_bytes.erase(0, after_headers);
      continue;
    }

    side.body_active = true;
    side.body_mode = message.body_mode;
    side.multipart = from_client &&
                     !multipartBoundaryFromContentType(message.content_type).empty();
    const std::string prefetched = side.undecided_bytes.substr(after_headers);
    side.undecided_bytes.clear();

    flow.parser.startBody(from_client, message.body_mode, message.declared_body_size);
    if (side.multipart && !prefetched.empty()) {
      emitMultipartEvents(flow, prefetched, now_ts, logger);
    }
    emitProgressEvents(flow,
                       side,
                       from_client,
                       flow.parser.feedBody("", from_client),
                       now_ts,
                       logger);
    logParserError(flow.parser, logger);
    break;
  }
}

void finishCloseDelimited(FlowTracker::FlowState& flow,
                          FlowTracker::ParserSideState& side,
                          bool from_client,
                          const std::string& now_ts,
                          Logger& logger) {
  if (!side.body_active || side.body_mode != BodyMode::CloseDelimited) {
    return;
  }

  flow.parser.finishCloseDelimited(from_client);
  emitProgressEvents(flow,
                     side,
                     from_client,
                     flow.parser.feedBody("", from_client),
                     now_ts,
                     logger);
  logParserError(flow.parser, logger);
}

void applyCloseSequence(FlowTracker::FlowState& flow,
                        FlowTracker::ParserSideState& side,
                        bool from_client,
                        uint32_t close_sequence,
                        const std::string& now_ts,
                        Logger& logger) {
  if (!side.next_sequence || !side.body_active ||
      side.body_mode != BodyMode::ContentLength || side.multipart) {
    return;
  }

  const int32_t distance =
      static_cast<int32_t>(close_sequence - *side.next_sequence);
  if (distance <= 0) {
    return;
  }

  const auto skipped = static_cast<uint64_t>(distance);
  side.next_sequence =
      *side.next_sequence + static_cast<uint32_t>(skipped);
  processSkippedPayloadBytes(flow, side, from_client, skipped, now_ts, logger);
}

}  // namespace

FlowTracker::FlowTracker(RuntimeConfig config, Logger& logger)
    : config_(std::move(config)), logger_(logger) {
  for (const auto& pattern : config_.lan_clients) {
    std::string error;
    lan_matcher_.addPattern(pattern, &error);
  }
}

bool FlowTracker::shouldTrackEndpoint(const Endpoint& src,
                                      const Endpoint& dst) const {
  return lan_matcher_.matches(src.ip) || lan_matcher_.matches(dst.ip);
}

void FlowTracker::onTcpData(const FlowKey& key,
                            const Endpoint& src,
                            const Endpoint& dst,
                            std::string_view bytes,
                            const std::string& now_ts) {
  onTcpData(key, src, dst, bytes, now_ts, std::nullopt);
}

void FlowTracker::onTcpData(const FlowKey& key,
                            const Endpoint& src,
                            const Endpoint& dst,
                            std::string_view bytes,
                            const std::string& now_ts,
                            uint32_t sequence) {
  onTcpData(key, src, dst, bytes, now_ts, std::optional<uint32_t>(sequence));
}

void FlowTracker::onTcpData(const FlowKey& key,
                            const Endpoint& src,
                            const Endpoint& dst,
                            std::string_view bytes,
                            const std::string& now_ts,
                            std::optional<uint32_t> sequence) {
  if (!shouldTrackEndpoint(src, dst)) {
    return;
  }

  auto it = flows_.find(key);
  if (it == flows_.end()) {
    if (flows_.size() >= config_.max_active_flows) {
      logger_.logTrackerDrop("max_active_flows");
      return;
    }
    it = flows_.emplace(std::piecewise_construct,
                        std::forward_as_tuple(key),
                        std::forward_as_tuple(config_, now_ts))
             .first;
  }

  FlowState& flow = it->second;
  flow.last_seen_ts = now_ts;

  if (!flow.client_side) {
    ParserSideState& side = sideStateFor(flow, key, src);
    const SequenceBytes filtered = sequenceFilteredBytes(side, bytes, sequence, false);
    if (filtered.immediate.empty() && filtered.pending.empty()) {
      return;
    }
    side.undecided_bytes.append(filtered.immediate.data(),
                                filtered.immediate.size());
    side.undecided_bytes.append(filtered.pending.data(),
                                filtered.pending.size());
    if (!looksLikeHttpRequestLine(side.undecided_bytes)) {
      if (side.undecided_bytes.size() > config_.max_header_bytes) {
        side.undecided_bytes.clear();
      }
      return;
    }
    flow.client_side = src;
    const std::string initial_bytes = std::move(side.undecided_bytes);
    processSegment(flow,
                   side,
                   src,
                   dst,
                   true,
                   initial_bytes,
                   now_ts,
                   logger_);
    return;
  }

  const bool from_client = sameEndpoint(src, *flow.client_side);
  ParserSideState& side = sideStateFor(flow, key, src);
  const bool can_skip_gap = side.body_active &&
                            side.body_mode == BodyMode::ContentLength &&
                            !side.multipart;
  const SequenceBytes filtered =
      sequenceFilteredBytes(side, bytes, sequence, can_skip_gap);
  if (filtered.immediate.empty() && filtered.pending.empty()) {
    return;
  }
  if (filtered.skipped > 0) {
    processSkippedPayloadBytes(flow,
                               side,
                               from_client,
                               filtered.skipped,
                               now_ts,
                               logger_);
  }
  if (!filtered.immediate.empty()) {
    processSegment(flow,
                   side,
                   src,
                   dst,
                   from_client,
                   filtered.immediate,
                   now_ts,
                   logger_);
  }
  if (!filtered.pending.empty()) {
    processSegment(flow,
                   side,
                   src,
                   dst,
                   from_client,
                   filtered.pending,
                   now_ts,
                   logger_);
  }
}

void FlowTracker::onTcpClose(const FlowKey& key, const std::string& now_ts) {
  auto it = flows_.find(key);
  if (it == flows_.end()) {
    return;
  }

  FlowState& flow = it->second;
  finishCloseDelimited(flow, flow.endpoint_a, flow.client_side && sameEndpoint(key.a, *flow.client_side), now_ts, logger_);
  finishCloseDelimited(flow, flow.endpoint_b, flow.client_side && sameEndpoint(key.b, *flow.client_side), now_ts, logger_);

  for (const auto& event : flow.detector.flushTimeout("tcp_close", now_ts)) {
    logger_.logTransfer(event);
  }
  flows_.erase(it);
}

void FlowTracker::onTcpClose(const FlowKey& key,
                             const Endpoint& src,
                             const std::string& now_ts) {
  onTcpClose(key, src, now_ts, std::nullopt);
}

void FlowTracker::onTcpClose(const FlowKey& key,
                             const Endpoint& src,
                             const std::string& now_ts,
                             uint32_t close_sequence) {
  onTcpClose(key,
             src,
             now_ts,
             std::optional<uint32_t>(close_sequence));
}

void FlowTracker::onTcpClose(const FlowKey& key,
                             const Endpoint& src,
                             const std::string& now_ts,
                             std::optional<uint32_t> close_sequence) {
  auto it = flows_.find(key);
  if (it == flows_.end()) {
    return;
  }

  FlowState& flow = it->second;
  flow.last_seen_ts = now_ts;
  const bool from_client =
      flow.client_side && sameEndpoint(src, *flow.client_side);
  ParserSideState& side = sideStateFor(flow, key, src);

  if (close_sequence) {
    applyCloseSequence(
        flow, side, from_client, *close_sequence, now_ts, logger_);
  }
  finishCloseDelimited(flow, side, from_client, now_ts, logger_);
  for (const auto& event :
       flow.detector.flushDirection(from_client, "tcp_close", now_ts)) {
    logger_.logTransfer(event);
  }

  side.body_active = false;
  side.multipart = false;
  side.body_mode = BodyMode::NoBody;
  side.pending_segments.clear();
  side.pending_sequence_bytes = 0;
}

void FlowTracker::cleanupIdle(const std::string& now_ts) {
  for (auto it = flows_.begin(); it != flows_.end();) {
    const auto idle_for = elapsedSeconds(it->second.last_seen_ts, now_ts);
    if (!idle_for || *idle_for < config_.flow_idle_timeout_sec) {
      ++it;
      continue;
    }

    for (const auto& event : it->second.detector.flushTimeout("idle_timeout", now_ts)) {
      logger_.logTransfer(event);
    }
    it = flows_.erase(it);
  }
}

}  // namespace hft
