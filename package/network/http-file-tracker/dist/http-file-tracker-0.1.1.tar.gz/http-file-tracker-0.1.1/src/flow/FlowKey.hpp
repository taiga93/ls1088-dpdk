#pragma once

#include "detect/TransferDetector.hpp"

#include <tuple>

namespace hft {

struct FlowKey {
  Endpoint a;
  Endpoint b;
  uint8_t protocol = 6;

  bool operator<(const FlowKey& other) const {
    return std::tie(a.ip, a.port, b.ip, b.port, protocol) <
           std::tie(other.a.ip, other.a.port, other.b.ip, other.b.port, other.protocol);
  }
};

inline FlowKey canonicalFlowKey(const Endpoint& x,
                                const Endpoint& y,
                                uint8_t protocol = 6) {
  if (std::tie(y.ip, y.port) < std::tie(x.ip, x.port)) {
    return FlowKey{y, x, protocol};
  }
  return FlowKey{x, y, protocol};
}

}  // namespace hft
