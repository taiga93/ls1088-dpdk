#pragma once

#include "config/RuntimeConfig.hpp"
#include "core/IpAddress.hpp"
#include "flow/FlowKey.hpp"
#include "http/HttpParser.hpp"
#include "log/Logger.hpp"

#include <map>
#include <optional>
#include <cstdint>
#include <string>
#include <string_view>

namespace hft {

class FlowTracker {
 public:
  struct ParserSideState {
    bool body_active = false;
    bool multipart = false;
    BodyMode body_mode = BodyMode::NoBody;
    std::string undecided_bytes;
    std::optional<uint32_t> next_sequence;
    std::map<uint32_t, std::string> pending_segments;
    size_t pending_sequence_bytes = 0;
  };

  struct FlowState {
    HttpParser parser;
    TransferDetector detector;
    std::string last_seen_ts;
    std::optional<Endpoint> client_side;
    ParserSideState endpoint_a;
    ParserSideState endpoint_b;

    FlowState(const RuntimeConfig& config, std::string now_ts)
        : parser(config.max_header_bytes, config.max_uri_bytes, config.max_filename_bytes),
          detector(config, now_ts),
          last_seen_ts(std::move(now_ts)) {}
  };

  FlowTracker(RuntimeConfig config, Logger& logger);

  void onTcpData(const FlowKey& key,
                 const Endpoint& src,
                 const Endpoint& dst,
                 std::string_view bytes,
                 const std::string& now_ts);
  void onTcpData(const FlowKey& key,
                 const Endpoint& src,
                 const Endpoint& dst,
                 std::string_view bytes,
                 const std::string& now_ts,
                 uint32_t sequence);
  void onTcpClose(const FlowKey& key,
                  const Endpoint& src,
                  const std::string& now_ts);
  void onTcpClose(const FlowKey& key,
                  const Endpoint& src,
                  const std::string& now_ts,
                  uint32_t close_sequence);
  void onTcpClose(const FlowKey& key, const std::string& now_ts);
  void cleanupIdle(const std::string& now_ts);

 private:
  RuntimeConfig config_;
  Logger& logger_;
  IpMatcher lan_matcher_;
  std::map<FlowKey, FlowState> flows_;

  bool shouldTrackEndpoint(const Endpoint& src, const Endpoint& dst) const;
  void onTcpData(const FlowKey& key,
                 const Endpoint& src,
                 const Endpoint& dst,
                 std::string_view bytes,
                 const std::string& now_ts,
                 std::optional<uint32_t> sequence);
  void onTcpClose(const FlowKey& key,
                  const Endpoint& src,
                  const std::string& now_ts,
                  std::optional<uint32_t> close_sequence);
};

}  // namespace hft
