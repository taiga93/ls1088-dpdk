#include "app/Version.hpp"

namespace hft {
std::string versionString() {
  return "0.1.1";
}
}  // namespace hft
