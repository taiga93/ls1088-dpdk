#pragma once

#include <string>

namespace hft {
std::string versionString();
}
