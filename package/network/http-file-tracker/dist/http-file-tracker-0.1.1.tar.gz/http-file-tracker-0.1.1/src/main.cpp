#include "app/Version.hpp"
#include "capture/PcapCapture.hpp"
#include "config/ArgsParser.hpp"
#include "log/Logger.hpp"

#include <atomic>
#include <chrono>
#include <csignal>
#include <iostream>
#include <string>
#include <thread>

namespace {
std::atomic<bool> running{true};

void handleSignal(int) {
  running = false;
}
}  // namespace

int main(int argc, char** argv) {
  if (argc == 2 && std::string(argv[1]) == "--version") {
    std::cout << hft::versionString() << "\n";
    return 0;
  }

  auto config = hft::parseArgs(argc, argv);
  if (!config.ok) {
    std::cerr << "http-file-tracker config error: " << config.error << "\n";
    return 2;
  }
  if (!config.config.enabled) {
    return 0;
  }

  std::signal(SIGINT, handleSignal);
  std::signal(SIGTERM, handleSignal);

  hft::SyslogLogger logger;
  hft::PcapCapture capture(config.config, logger);
  std::string error;
  if (!capture.start(&error)) {
    logger.logWarning(error);
    std::cerr << "http-file-tracker capture error: " << error << "\n";
    return 1;
  }

  while (running) {
    std::this_thread::sleep_for(std::chrono::seconds(1));
  }
  capture.stop();
  return 0;
}
