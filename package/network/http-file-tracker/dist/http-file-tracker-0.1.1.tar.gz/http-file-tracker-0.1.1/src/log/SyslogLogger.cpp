#include "log/Logger.hpp"

#include "log/KvLog.hpp"

#include <syslog.h>

namespace hft {

SyslogLogger::SyslogLogger() {
  openlog("http-file-tracker", LOG_PID, LOG_DAEMON);
}

SyslogLogger::~SyslogLogger() {
  closelog();
}

void SyslogLogger::logTransfer(const TransferEvent& event) {
  syslog(LOG_INFO, "%s", formatTransferEvent(event).c_str());
}

void SyslogLogger::logTrackerDrop(const std::string& reason) {
  syslog(LOG_WARNING, "%s", formatTrackerDrop(reason).c_str());
}

void SyslogLogger::logWarning(const std::string& message) {
  syslog(LOG_WARNING, "%s", formatWarning(message).c_str());
}

}  // namespace hft
