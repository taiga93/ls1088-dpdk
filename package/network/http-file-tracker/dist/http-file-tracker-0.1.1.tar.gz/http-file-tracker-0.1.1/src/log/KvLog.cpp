#include "log/KvLog.hpp"

#include <sstream>

namespace hft {
namespace {

std::string toString(TransferKind value) {
  switch (value) {
    case TransferKind::FileDetected:
      return "file_detected";
    case TransferKind::BodyTransfer:
      return "body_transfer";
  }
  return "body_transfer";
}

std::string toString(TransferStatus value) {
  switch (value) {
    case TransferStatus::Complete:
      return "complete";
    case TransferStatus::Partial:
      return "partial";
    case TransferStatus::Timeout:
      return "timeout";
    case TransferStatus::Unsupported:
      return "unsupported";
  }
  return "partial";
}

std::string toString(Direction value) {
  switch (value) {
    case Direction::Upload:
      return "upload";
    case Direction::Download:
      return "download";
    case Direction::LanUpload:
      return "lan_upload";
    case Direction::LanDownload:
      return "lan_download";
  }
  return "download";
}

bool plainValue(const std::string& value) {
  if (value.empty()) {
    return false;
  }
  for (char ch : value) {
    const bool ok = (ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') ||
                    (ch >= '0' && ch <= '9') || ch == '.' || ch == ':' ||
                    ch == '_' || ch == '-' || ch == '/';
    if (!ok) {
      return false;
    }
  }
  return true;
}

std::string escapeValue(const std::string& value) {
  if (plainValue(value)) {
    return value;
  }

  std::ostringstream out;
  out << '"';
  for (char ch : value) {
    if (ch == '"' || ch == '\\') {
      out << '\\';
    }
    out << ch;
  }
  out << '"';
  return out.str();
}

void add(std::ostringstream& out, const std::string& key, const std::string& value) {
  out << ' ' << key << '=' << escapeValue(value.empty() ? "unknown" : value);
}

void addNumber(std::ostringstream& out, const std::string& key, uint64_t value) {
  out << ' ' << key << '=' << value;
}

}  // namespace

std::string formatTransferEvent(const TransferEvent& event) {
  std::ostringstream out;
  out << "http-file-tracker event=http_transfer";
  add(out, "kind", toString(event.kind));
  add(out, "status", toString(event.status));
  if (!event.reason.empty()) {
    add(out, "reason", event.reason);
  }
  add(out, "direction", toString(event.direction));
  add(out, "client_ip", event.client_ip);
  add(out, "peer_ip", event.peer_ip);
  add(out, "host", event.host);
  add(out, "uri", event.uri);
  add(out, "filename", event.filename.empty() ? "unknown" : event.filename);
  add(out, "content_type", event.content_type.empty() ? "unknown" : event.content_type);
  addNumber(out, "bytes_transferred", event.bytes_transferred);
  if (event.declared_size) {
    addNumber(out, "declared_size", *event.declared_size);
  } else {
    add(out, "declared_size", "unknown");
  }
  add(out, "start_ts", event.start_ts);
  add(out, "end_ts", event.end_ts);
  addNumber(out, "duration_ms", event.duration_ms);
  add(out, "confidence", event.confidence);
  if (!event.truncated_fields.empty()) {
    std::ostringstream joined;
    for (size_t i = 0; i < event.truncated_fields.size(); ++i) {
      if (i != 0) {
        joined << ',';
      }
      joined << event.truncated_fields[i];
    }
    add(out, "truncated_fields", joined.str());
  }
  return out.str();
}

std::string formatTrackerDrop(const std::string& reason) {
  std::ostringstream out;
  out << "http-file-tracker event=tracker_drop";
  add(out, "reason", reason);
  return out.str();
}

std::string formatWarning(const std::string& message) {
  std::ostringstream out;
  out << "http-file-tracker event=warning";
  add(out, "message", message);
  return out.str();
}

}  // namespace hft
