#pragma once

#include "http/HttpTypes.hpp"

#include <string>

namespace hft {

std::string formatTransferEvent(const TransferEvent& event);
std::string formatTrackerDrop(const std::string& reason);
std::string formatWarning(const std::string& message);

}  // namespace hft
