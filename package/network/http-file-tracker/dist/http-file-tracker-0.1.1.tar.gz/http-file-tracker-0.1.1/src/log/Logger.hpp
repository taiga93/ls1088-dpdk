#pragma once

#include "http/HttpTypes.hpp"

#include <string>

namespace hft {

class Logger {
 public:
  virtual ~Logger() = default;
  virtual void logTransfer(const TransferEvent& event) = 0;
  virtual void logTrackerDrop(const std::string& reason) = 0;
  virtual void logWarning(const std::string& message) = 0;
};

class SyslogLogger final : public Logger {
 public:
  SyslogLogger();
  ~SyslogLogger() override;

  void logTransfer(const TransferEvent& event) override;
  void logTrackerDrop(const std::string& reason) override;
  void logWarning(const std::string& message) override;
};

}  // namespace hft
